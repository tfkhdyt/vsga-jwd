<?php
function generateNoResi() { // function untuk meng-generate no resi acak
  return rand(10000000000000, 20000000000000); // buat angka acak dari rentang 10000000000000 sampai 20000000000000
}
