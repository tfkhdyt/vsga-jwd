<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Combo Box</title>
</head>

<body>
  <h3>Kendaraan apa yang anda miliki?</h3>
  <form>
    <select>
      <option value="Pesawat">Pesawat</option>
      <option value="Mobil">Mobil</option>
      <option value="Motor">Motor</option>
      <option value="Sepeda">Sepeda</option>
    </select>
    <br><br>
    <button type="submit">Submit</button>
  </form>
</body>

</html>