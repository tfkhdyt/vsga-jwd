<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Button Choice</title>
</head>

<body>
  <h3>Pilih Makanan</h3>
  <form>
    <input type="button" value="Nasi Goreng"> <br>
    <input type="button" value="Mie Ayam"> <br>
    <input type="button" value="Bakso"> <br>
    <input type="button" value="Soto Ayam"> <br> <br>
    <button type="submit">Submit</button>
  </form>
</body>

</html>