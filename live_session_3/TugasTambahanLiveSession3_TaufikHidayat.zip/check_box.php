<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Check Box</title>
</head>

<body>
  <h3>Kendaraan apa yang anda miliki?</h3>
  <form>
    <input type="checkbox" value="Mobil">Mobil <br>
    <input type="checkbox" value="Motor">Motor <br>
    <input type="checkbox" value="Sepeda">Sepeda <br>
    <input type="checkbox" value="Pesawat">Pesawat <br> <br>
    <button type="submit">Submit</button>
  </form>
</body>

</html>