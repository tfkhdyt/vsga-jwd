<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Pilih Jenis Kelamin</title>
</head>

<body>
  <h3>Pilih jenis kelamin</h3>
  <form>
    <input type="radio" name="gender" id="gender" value="laki-laki" /> Laki-laki <br>
    <input type="radio" name="gender" id="gender" value="perempuan" /> Perempuan <br>
    <input type="radio" name="gender" id="gender" value="lainnya" /> Lainnya <br>
    <button type="submit">Submit</button>
  </form>
</body>

</html>