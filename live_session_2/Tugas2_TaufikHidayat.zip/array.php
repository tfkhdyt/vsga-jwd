<?php
$pilih = ["Handphone", "Notebook", "Netbook", "BB"];
echo "Pilihan saya: $pilih[1]";
