<?php
$ana = true; // deklarasi TRUE pada $ana
echo "Nilai ana = $ana <br>"; // akan bernilai 1
$aryani = false; // deklarasi FALSE pada $aryani
echo "Nilai aryani = $aryani"; // akan bernilai kosong
