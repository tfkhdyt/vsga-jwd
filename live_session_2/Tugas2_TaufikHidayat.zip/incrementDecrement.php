<?php
$x = 4;
$x++;
echo "$x <br>";
$x = 4;
$x--;
echo "$x";
