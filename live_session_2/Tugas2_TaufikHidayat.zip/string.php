<?php
$nama_depan = "Taufik";
$nama_belakang = "Hidayat";
$nama_lengkap = "$nama_depan $nama_belakang";

echo "Nama depan: $nama_depan <br>";
echo "Nama belakang: $nama_belakang <br>";
echo "Nama lengkap: $nama_lengkap";
