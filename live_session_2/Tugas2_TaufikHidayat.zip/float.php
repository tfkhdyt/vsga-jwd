<?php

$nilai_matematika = 5.1;
$nilai_IPA = 6.7;
$nilai_bahasa_indonesia = 9.3;

$rata_rata = ($nilai_matematika + $nilai_IPA + $nilai_bahasa_indonesia) / 3;

echo "Matematika: $nilai_matematika <br>";
echo "IPA: $nilai_IPA <br>";
echo "Bahasa Indonesia: $nilai_bahasa_indonesia <br>";

var_dump($rata_rata);
