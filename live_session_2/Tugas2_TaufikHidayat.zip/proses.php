<?php
echo $_POST["nama"] . "<br>";
echo $_POST["email"];
